PROKRITIR HAAT - STORE FILES
============================

Files
- index.html          : puro website (HTML + CSS + JavaScript)
- config.js           : database-er URL ar key ekhane boshate hobe
- supabase-setup.sql  : database toiri korar SQL (ekbar run korben)
- store-data.json     : shurur sample data (database na thakle eta use hoy)
- img/logo.png        : apnar logo (boro size)

DATABASE (Supabase) SETUP - ei step gulo korle kono data kokhono haraibe na
1. supabase.com -> Sign up -> "New project". Naam din, ekta database password din,
   Region: Singapore. Project toiri hote 1-2 minute lage.
2. Left menu: SQL Editor -> New query -> supabase-setup.sql file-er shob kichu paste kore RUN.
3. Authentication -> Sign In / Providers -> Email: "Confirm email" OFF korun. (Customer ar admin
   account shathe shathe chalu hote hole eta OFF thakte hobe.) "Secure email change" thakle seta-o OFF.
4. Authentication -> URL Configuration: "Site URL" e apnar live site-er address din (https://...).
   "Redirect URLs"-e-o oi address add korun. (Admin-er password reset email-er jonno.)
5. Project Settings -> API: "Project URL" ar "anon public" (ba publishable) key copy korun.
6. config.js file khule duto ta "" er bhitore paste korun. Save korun.
7. Pura folder (index.html, config.js, store-data.json, img) hosting-e upload korun
   (Netlify Drop / Cloudflare Pages).
8. Site-er address-er sheshe #admin likhe (ba footer-er (c) lekhay 5 bar click kore) dhukun.
   "Create your admin account" screen ashbe. Gmail + password diye account banan.
   ** Eta site live korar shathe shathe, onno keu dhukar age kore nin. **
   Prothom je account banay shei admin hoy, tarpor ar keu admin hote pare na.

Ki ki database-e save hoy (browser clear korleo jabe na)
- Product, dam, discount, category, banner, About us, logo, setting, photo
  (admin-e edit korlei auto save hoy, customer-ra shathe shathe dekhe, upload korte hoy na)
- Shob order (customer WhatsApp-e pathanor shathe shathe database-e joma hoy)
- Admin account (Gmail + password), customer account (mobile + password), "My orders"
- Order history ar Monthly report asol order theke ashe

Admin
- Admin profile tab: naam, Gmail, password bodlano.
- Password bhule gele sign in screen-e "Forgot password?" -> Gmail-e reset link jabe.

Customer
- Create account / Sign in (mobile + password), je kono phone/computer theke.
- Customer-er password bhule gele WhatsApp-e janale apni Supabase dashboard theke reset korte paren.

Dhyan dite hobe
- Supabase free plan e 7 din kew site e na dhukle project "pause" hoy (data thake, kintu site bondho
  hoye jay). Dashboard theke "Restore" korle abar chole. Bebsha shuru hole paid plan nite paren.
- Free plan-er limit: 500 MB database, 1 GB photo storage.
- config.js faka thakle site "local mode"-e chole: data shudhu oi browser-e thake (test-er jonno).
- Claude-er preview link-e database connect hoy na. Nijer hosting-e live kore test korun.
